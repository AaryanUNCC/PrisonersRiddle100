/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package theprisonersproblem;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 *
 * @author abhay
 */
public class PrisonersLinkedList 
{

    public PrisonersLinkedList()
    {
        
    }

    public boolean searchForBoxNumber(int PrisnorNum, ArrayList<Box> theBoxes)
    {
        int numSearches = 0;
        int intPointerID = PrisnorNum;

        while(numSearches <= (theBoxes.size()/2))
        {
            intPointerID = returnPointerID(intPointerID, theBoxes);
            
            if(intPointerID == PrisnorNum)
            {
                return true;
            }
            numSearches++;
        }
        return false;
    }          
         
    public int returnPointerID(int boxid, ArrayList<Box> theBoxes)
    {     
        int PointerID = 0;

        for (Box b: theBoxes)
        {
           if(b.id == boxid)
           {
               PointerID = b.innerID;
               break;
           }
        }

        return PointerID;
    }  
}
