/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package theprisonersproblem;

import java.util.ArrayList;
import java.util.Random;
import java.util.*;
import java.util.List;

/**
 *
 * @author abhay
 */
public class theRiddle {

    int TotalPersons = 100;
    int TotalBoxes = 50;
    ArrayList<Prisoner> thePrisoners = new ArrayList<>(TotalPersons);
    ArrayList<Box> theBoxes = new ArrayList<>(TotalPersons);
    PrisonersLinkedList search = new PrisonersLinkedList();
    ArrayList<Integer> arrayList = new ArrayList<Integer>();
    Random randomGenerator = new Random();
    int count = 0;
    int successCount = 0;
    int timesFreed = 0;
    int timesExecuted = 0;
    
    public void ResetVariables()
    {
        thePrisoners = new ArrayList<>(TotalPersons);   
        theBoxes = new ArrayList<>(TotalPersons);       
        search = new PrisonersLinkedList();
        arrayList = new ArrayList<Integer>();

        count = 0;
        successCount = 0;

    }

    public theRiddle(int numIterations) {

        for (int n = 0; n < numIterations; n++) {
            
            ResetVariables();
            assemblePrisoners();
            
            Collections.shuffle(arrayList);
            for (int i = 0; i < thePrisoners.size(); i++) {
                thePrisoners.get(i).assignedNumber = i;
                theBoxes.get(i).id = i;

                int temp = arrayList.get(i);
                if (temp == i) // 
                {
                    theBoxes.get(i).innerID = arrayList.get(i);
                } else {
                    theBoxes.get(i).innerID = temp;
                }
            }

            for (Prisoner p : thePrisoners) {
                boolean success = search.searchForBoxNumber(p.assignedNumber, theBoxes);
                if (success == true) {
                    System.out.println("Success - Prisnor box found :" + p.assignedNumber);
                    successCount++;
                }
                System.out.println("Next Prisnor:" + p.assignedNumber);
            }

            if (successCount == thePrisoners.size()) {
                System.out.println("Congratulations, you have all been freed!");
                timesFreed++;
            } else {
                System.out.println("The experiment has failed: all prisoners will now be executed");
                timesExecuted++;
            }
        }
        System.out.println("The experiment has succeded " + timesFreed + " times");
        System.out.println("The experiment has failed " + timesExecuted + " times");
        double result = ((double)timesFreed/(double)(timesFreed + timesExecuted));
        System.out.println(" The final success rate is " + result );
    }

    public void assemblePrisoners() {
        for (int i = 0; i < TotalPersons; i++) {
            thePrisoners.add(new Prisoner());
            theBoxes.add(new Box());
            arrayList.add(i + 1);
        }
    }

    public ArrayList<Prisoner> returnList() {
        return thePrisoners;
    }

    public ArrayList<Box> returnBoxList() {
        return theBoxes;
    }

    public void calculateIterations() {
        System.out.println("The prisoners have succeeded " + timesFreed + " times");
        System.out.println("The prisoners have failed " + timesExecuted + " times");
        System.out.println("The success rate for the program is " + timesFreed / (timesFreed + timesExecuted));
    }

}
